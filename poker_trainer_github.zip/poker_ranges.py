import random

ranges_por_posicao = {
    "BTN": {
        "call": ["AJs", "KQs", "TT", "99", "88"],
        "fold": ["A9o", "K8o", "Q9o", "J9o"],
        "jam": ["AKs", "QQ", "JJ", "AQo", "A5s"]
    },
    "CO": {
        "call": ["ATs", "KJs", "99"],
        "fold": ["Q8o", "J8o", "T8o"],
        "jam": ["AKo", "AJs", "TT", "AQs"]
    },
    "MP": {
        "call": ["KQs", "JJ", "AQs"],
        "fold": ["Q9o", "J9o"],
        "jam": ["AKo", "QQ", "AJs"]
    },
    "UTG": {
        "call": ["QQ", "AKs"],
        "fold": ["AJo", "KQo"],
        "jam": ["AA", "KK", "AQo"]
    },
    "SB": {
        "call": ["Limp / Call 3x"],
        "fold": ["Limp / Fold"],
        "jam": ["Limp / Jam", "Raise / Call Jam"]
    }
}

def get_hand_action(posicao, mao):
    for acao, maos in ranges_por_posicao.get(posicao, {}).items():
        if mao in maos:
            return acao
    return "fold"

def sample_hand():
    posicao = random.choice(list(ranges_por_posicao.keys()))
    acao = random.choice(list(ranges_por_posicao[posicao].keys()))
    mao = random.choice(ranges_por_posicao[posicao][acao])
    return posicao, mao, acao