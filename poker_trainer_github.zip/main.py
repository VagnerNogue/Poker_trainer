import random
from poker_ranges import get_hand_action, sample_hand

def main():
    print("Treinador de Decisão Pré-Flop (20-40bb) - v1.0\n")
    score = 0
    total = 0

    while True:
        pos, hand, action_correcta = sample_hand()
        print(f"Posição: {pos} | Mão: {hand}")
        print("Escolha sua ação:")
        print("1 - Fold")
        print("2 - Call vs 3bet")
        print("3 - 4bet Jam")
        escolha = input("Sua ação (1/2/3 ou Q para sair): ").strip().upper()

        if escolha == "Q":
            break

        acao_map = {"1": "fold", "2": "call", "3": "jam"}
        acao_usuario = acao_map.get(escolha, "")

        if not acao_usuario:
            print("Entrada inválida. Tente novamente.")
            continue

        if acao_usuario == action_correcta:
            print("✔️ Correto!")
            score += 1
        else:
            print(f"❌ Incorreto. A ação correta era: {action_correcta.upper()}")

        total += 1
        print(f"Pontuação: {score}/{total} ({(score/total)*100:.1f}%)\n")

if __name__ == "__main__":
    main()